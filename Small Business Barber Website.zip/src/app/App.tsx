import { Scissors, Clock, MapPin, Phone, Mail, Star, Award, Users } from 'lucide-react';
import { ImageWithFallback } from './components/figma/ImageWithFallback';

export default function App() {
  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Navigation */}
      <nav className="bg-neutral-900 text-white sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <Scissors className="w-6 h-6" />
              <span className="text-xl font-bold">A2Z Barber</span>
            </div>
            <div className="hidden md:flex gap-6">
              <a href="#home" className="hover:text-amber-500 transition-colors">Home</a>
              <a href="#services" className="hover:text-amber-500 transition-colors">Services</a>
              <a href="#about" className="hover:text-amber-500 transition-colors">About</a>
              <a href="#gallery" className="hover:text-amber-500 transition-colors">Gallery</a>
              <a href="#contact" className="hover:text-amber-500 transition-colors">Contact</a>
            </div>
            <a href="#contact" className="bg-amber-500 hover:bg-amber-600 px-4 py-2 rounded transition-colors">
              Book Now
            </a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative h-[600px] flex items-center justify-center text-white">
        <div className="absolute inset-0 bg-neutral-900">
          <ImageWithFallback 
            src="https://images.unsplash.com/photo-1585747860715-2ba37e788b70?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBiYXJiZXIlMjBzaG9wJTIwaW50ZXJpb3J8ZW58MXx8fHwxNzc5OTM2NjYxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Modern barber shop interior"
            className="w-full h-full object-cover opacity-40"
          />
        </div>
        <div className="relative z-10 text-center px-4">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">A2Z Barber</h1>
          <p className="text-xl md:text-2xl mb-8">From A to Z, We've Got Your Style Covered</p>
          <a href="#contact" className="bg-amber-500 hover:bg-amber-600 text-white px-8 py-3 rounded-lg inline-block transition-colors">
            Schedule Your Appointment
          </a>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-4">Our Services</h2>
          <p className="text-center text-neutral-600 mb-12">Premium grooming services tailored to your style</p>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow">
              <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <Scissors className="w-8 h-8 text-amber-600" />
              </div>
              <h3 className="text-xl font-bold mb-2">Haircut</h3>
              <p className="text-neutral-600 mb-4">Classic and modern cuts tailored to your face shape and personal style.</p>
              <p className="text-2xl font-bold text-amber-600">$35</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow">
              <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <Award className="w-8 h-8 text-amber-600" />
              </div>
              <h3 className="text-xl font-bold mb-2">Beard Trim</h3>
              <p className="text-neutral-600 mb-4">Professional beard shaping and trimming for the perfect look.</p>
              <p className="text-2xl font-bold text-amber-600">$25</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow">
              <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <Star className="w-8 h-8 text-amber-600" />
              </div>
              <h3 className="text-xl font-bold mb-2">Hot Towel Shave</h3>
              <p className="text-neutral-600 mb-4">Luxurious traditional straight razor shave with hot towel treatment.</p>
              <p className="text-2xl font-bold text-amber-600">$40</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow">
              <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <Scissors className="w-8 h-8 text-amber-600" />
              </div>
              <h3 className="text-xl font-bold mb-2">Haircut & Beard</h3>
              <p className="text-neutral-600 mb-4">Complete grooming package for hair and beard.</p>
              <p className="text-2xl font-bold text-amber-600">$55</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow">
              <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <Users className="w-8 h-8 text-amber-600" />
              </div>
              <h3 className="text-xl font-bold mb-2">Kids Haircut</h3>
              <p className="text-neutral-600 mb-4">Patient and friendly service for children under 12.</p>
              <p className="text-2xl font-bold text-amber-600">$25</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow">
              <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <Star className="w-8 h-8 text-amber-600" />
              </div>
              <h3 className="text-xl font-bold mb-2">Hair Coloring</h3>
              <p className="text-neutral-600 mb-4">Professional hair coloring and highlighting services.</p>
              <p className="text-2xl font-bold text-amber-600">$60+</p>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4 bg-neutral-900 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold mb-6">About A2Z Barber</h2>
              <p className="text-neutral-300 mb-4">
                Welcome to A2Z Barber, where traditional barbering meets modern style. With over 15 years of experience, 
                we pride ourselves on delivering exceptional grooming services in a relaxed and friendly atmosphere.
              </p>
              <p className="text-neutral-300 mb-4">
                Our skilled barbers are passionate about their craft and stay updated with the latest trends and techniques. 
                Whether you're looking for a classic cut or a contemporary style, we've got you covered from A to Z.
              </p>
              <p className="text-neutral-300 mb-6">
                We believe that a great haircut is more than just a service—it's an experience that leaves you feeling 
                confident and looking your best.
              </p>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-3xl font-bold text-amber-500">4.7★</div>
                  <div className="text-neutral-400">Rating</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-amber-500">59</div>
                  <div className="text-neutral-400">Reviews</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-amber-500">A–Z</div>
                  <div className="text-neutral-400">Covered</div>
                </div>
              </div>
            </div>
            <div className="relative h-[400px] rounded-lg overflow-hidden">
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1605497788044-5a32c7078486?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBoYWlyY3V0JTIwYmFyYmVyfGVufDF8fHx8MTc3OTkzNjY2Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Professional barber at work"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section id="gallery" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-4">Our Work</h2>
          <p className="text-center text-neutral-600 mb-12">See the quality of our craftsmanship</p>
          
          <div className="grid md:grid-cols-3 gap-6">
            <div className="relative h-80 rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow">
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1605497788044-5a32c7078486?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBoYWlyY3V0JTIwYmFyYmVyfGVufDF8fHx8MTc3OTkzNjY2Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Professional haircut example"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
            <div className="relative h-80 rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow">
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1503951914875-452162b0f3f1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWFyZCUyMHRyaW0lMjBncm9vbWluZ3xlbnwxfHx8fDE3Nzk3NTkyOTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Beard grooming example"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
            <div className="relative h-80 rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow">
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1596362601603-b74f6ef166e4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYXJiZXIlMjBzY2lzc29ycyUyMHRvb2xzfGVufDF8fHx8MTc3OTkzNjY2Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Barber tools"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4 bg-neutral-100">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-4">Visit Us</h2>
          <p className="text-center text-neutral-600 mb-12">We look forward to serving you</p>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-amber-600" />
              </div>
              <h3 className="text-xl font-bold mb-4">Hours</h3>
              <div className="text-neutral-600 space-y-1 text-sm">
                <p className="flex justify-between gap-4"><span>Mon – Wed</span><span>9:00 AM – 5:30 PM</span></p>
                <p className="flex justify-between gap-4"><span>Thursday</span><span>9:00 AM – 5:30 PM</span></p>
                <p className="flex justify-between gap-4"><span>Friday</span><span>9:00 AM – 5:30 PM</span></p>
                <p className="flex justify-between gap-4"><span>Saturday</span><span>9:00 AM – 3:30 PM</span></p>
                <p className="flex justify-between gap-4 text-red-500"><span>Sunday</span><span>Closed</span></p>
              </div>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-8 h-8 text-amber-600" />
              </div>
              <h3 className="text-xl font-bold mb-4">Location</h3>
              <div className="text-neutral-600">
                <p>Shop 2/195 Great Western Hwy</p>
                <p>Hazelbrook NSW 2779</p>
                <a
                  href="https://maps.google.com/?q=Shop+2/195+Great+Western+Hwy+Hazelbrook+NSW+2779"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-amber-600 hover:underline text-sm mt-2 inline-block"
                >
                  Get Directions →
                </a>
              </div>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Phone className="w-8 h-8 text-amber-600" />
              </div>
              <h3 className="text-xl font-bold mb-4">Contact</h3>
              <div className="text-neutral-600 space-y-2">
                <a href="tel:0404022662" className="flex items-center justify-center gap-2 hover:text-amber-600 transition-colors">
                  <Phone className="w-4 h-4" />
                  0404 022 662
                </a>
                <div className="flex items-center justify-center gap-2 mt-2">
                  <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                  <span>4.7 stars · 59 reviews</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-12 text-center">
            <a
              href="tel:0404022662"
              className="bg-amber-500 hover:bg-amber-600 text-white px-8 py-3 rounded-lg inline-block transition-colors"
            >
              Call to Book Now
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-neutral-900 text-white py-8 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Scissors className="w-6 h-6" />
            <span className="text-xl font-bold">A2Z Barber</span>
          </div>
          <p className="text-neutral-400 mb-4">From A to Z, We've Got Your Style Covered</p>
          <p className="text-neutral-500 text-sm">© 2026 A2Z Barber. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
